# ME/CFS JCM Reproducibility Package

Manuscript: **Complementary Health Approach Use and Treatment-Seeking Patterns among U.S. Adults Reporting Clinician-Diagnosed ME/CFS: A Quota-Sampled Cross-Sectional Survey**

Repository release: 2026-10-02 UTC (October 1, 2026 in America/New_York)

## Purpose

This package provides the de-identified respondent-level analytic dataset, variable manifest, frozen analysis specification, analysis code, and verification outputs used to reproduce the final manuscript tables and inferential results. It is designed to run directly from the included CSV and does not require the original parent-survey SPSS file.

The analysis is exploratory and cross-sectional. It estimates associations between reported clinician-diagnosed ME/CFS and prior-year intervention use, favorability among users, and expected helpfulness for unused interventions. It does not establish causality, efficacy, safety, or within-person treatment response.

## Verified release and manuscript alignment

This release was run from the included CSV using Python 3.12.14. It passes **158 input-data checks** and **949 checks across every row of Tables 1–5**, reproduces all 123 models (20 Firth), and regenerates Figure 1 from the fitted results. The input CSV is unchanged from the October 1 reconciled package.

**One Methods reporting correction remains in the source manuscript:** the denominator-range sentence is stale. The correct CHA ranges are 102–2,864 for favorability and 734–3,017 for expectation. The full ranges including conventional comparators differ. See `MANUSCRIPT_RECONCILIATION.md` for all ranges and the exact replacement paragraph. All table estimates agree; no data or estimates were changed to force agreement.

## Files

- `Reproduce.py`: recommended single-command entry point; validates inputs, fits models, builds outputs, and fails if verification does not pass.
- `Build_Outputs.py`: generates Tables 1–5 (CSV and a readable HTML document), Figure 1 (300-dpi PNG and vector PDF), figure data, full table audit, denominator ranges, and findings summary.
- `reference/manuscript_tables.json`: independent snapshot of the five source-manuscript tables for validation, with manuscript filename/hash. Numerical targets are never used to fill calculated results.
- `MANUSCRIPT_RECONCILIATION.md`: precise verification scope, rounding rules, and denominator sentence correction.
- `DATA_PROVENANCE.md`: retained/excluded fields, input lineage, missing-value conventions, and sharing scope.

- `CFS_JCM_public_data.csv`: de-identified analytic dataset, already restricted to the Study 2 analytic sample.
- `CFS_JCM_variable_manifest.csv`: variable descriptions and coding for the public dataset.
- `Analysis_Config_CFS.json`: frozen analysis specification.
- `Analysis_CFS.py`: end-to-end analysis and validation pipeline.
- `requirements.txt`: Python package versions used for the final verification run.
- `analysis_outputs/`: full-precision results, manuscript-ready results, participant characteristics, missingness, variable map, invariant checks, manuscript validation, and run metadata.
- `SHA256SUMS.txt`: SHA-256 checksums for the packaged files (excluding the checksum file itself).

## Run the analysis

Tested on Python **3.12.14** with the pinned packages in `requirements.txt`; the preceding numerical package was also verified on Python 3.13.5. Python 3.12 is recommended. From the extracted repository folder, run:

```bash
python -m pip install -r requirements.txt
python Reproduce.py
```

The run writes to `analysis_outputs/` and overwrites the bundled outputs there. To keep the bundled outputs, use `python Reproduce.py --output-dir my_rerun`. No original SPSS file, Google Drive mount, credentials, internet access during analysis, or proprietary software is required. Installing dependencies may require internet access.

The model engine can also be run separately:

```bash
python Analysis_CFS.py --data CFS_JCM_public_data.csv --spec Analysis_Config_CFS.json --output-dir analysis_outputs
python Build_Outputs.py --output-dir analysis_outputs
```

The JSON records the frozen analysis specification; the engine implements its fixed study-specific coding and is not a general-purpose configurable modeling framework. Use `Reproduce.py` for the complete validation and release outputs.

A successful run should report:

- analytic N = 3,022
- ME/CFS reported = 167
- comparison = 2,855
- 28 complementary health approaches and 7 conventional comparators
- 102 CHA models + 21 conventional-comparator models = 123 total models
- 20 adjusted models fit with Firth penalized likelihood
- all structural invariants passed
- all 949 full-table checks passed, plus the selected headline checks
- all 123 adjusted models converged; all 20 Firth intervals used profile penalized likelihood

## Exposure definition

The exposure variable is `HXM_ChronicFatigueSyndrome`. A case is a respondent reporting that they currently had, or had in the past year, chronic fatigue syndrome as diagnosed by a medical professional. The manuscript refers to this survey-defined exposure as ME/CFS for readability. Formal ME/CFS diagnostic criteria were not assessed.

## Adjustment variables

Every adjusted model includes:

- corrected insurance status
- sex assigned at birth
- education (2 levels)
- age (4 levels)
- race/ethnicity (4 regression levels)
- residence size (3 levels)
- employment (3 levels)
- poverty (3 levels)
- U.S. region (4 levels)
- BMI (4 levels)

### Corrected insurance

`insurance_corrected` is the finalized binary covariate: insured if public or private coverage was reported, otherwise uninsured. Expected counts are 2,702 insured and 320 uninsured.

### Race/ethnicity regression coding

The verified four-level regression coding is:

1. White/Caucasian, non-Hispanic - reference
2. Black/African American, non-Hispanic
3. Hispanic
4. All other responses, including Asian non-Hispanic and the remaining sparse categories

The manuscript retains five categories for descriptive Table 1 reporting but collapses sparse categories for regression. This package corrects earlier documentation that had incorrectly described the all-other group as the reference level.

## Outcome construction

### Use

Prior-year use is binary. Category and overall CHA-use composites are positive if any constituent CHA was used.

### Favorability

For an individual modality, analysis is restricted to users of that modality; ratings 4-6 on the six-point scale are positive.

For category and overall composites, the mean of available constituent favorability ratings is calculated when at least one constituent rating is available. The historically implemented analysis classified a composite as positive when the mean was **greater than or equal to 3.5**. The manuscript now describes this implementation exactly.

### Expected helpfulness

For an individual modality, analysis is restricted to nonusers of that modality; ratings 4-6 are positive.

For category and overall composites, the mean is calculated from available expectation ratings for **unused constituent modalities** and is positive when the mean is greater than or equal to 3.5. A respondent can therefore contribute to a category expectation composite even if they used a different modality in that category. The composite is missing only when no relevant constituent expectation rating is available.

## Statistical analysis

The pipeline reports group-specific event counts and proportions, then estimates unadjusted and covariate-adjusted odds ratios with 95% confidence intervals.

- Unadjusted odds ratios use the ordinary 2x2 logistic/odds-ratio estimand; zero-cell contrasts are reported as not estimable.
- Adjusted maximum-likelihood logistic regression is the default.
- An adjusted model is refit with Firth penalized likelihood when a prespecified sparse-data or instability criterion is met, including an exposure-by-outcome cell below 5, separation/maximum-likelihood instability, or an initial Wald confidence-limit ratio above 50.
- Firth models use profile penalized-likelihood 95% confidence intervals and penalized likelihood-ratio p-values.
- Benjamini-Hochberg FDR correction is applied jointly across all 102 adjusted CHA models.
- The 21 conventional-comparator models form a separate exploratory family and retain nominal p-values.

The final run found a maximum design-matrix VIF of 2.7941 across all models and a maximum ME/CFS exposure VIF of 1.3102.

## Reconciled headline results

The final reproducible analysis supports the manuscript's central interpretation of broad treatment seeking rather than substitution. Important sparse-data/FDR reconciliations are:

- Any physical CHA use: aOR 2.22 (95% CI 1.60-3.07)
- Any nutritional CHA use: aOR 2.25 (1.34-3.80), q = 0.019
- Any combined CHA use: aOR 1.89 (1.24-2.88), q = 0.021
- Any systems approach use: aOR 1.99 (1.32-3.01), q = 0.010
- Any CHA use: aOR 2.46 (0.97-8.91), p = 0.061, q = 0.206
- Mindfulness favorability among users: aOR 0.37 (0.19-0.70), q = 0.019
- Naturopathy favorability among users: aOR 5.88 (1.17-60.44), p = 0.030, q = 0.117; this is imprecise and does not meet the FDR threshold
- Psychotherapy favorability among users, conventional comparator: aOR 3.21 (0.97-16.66), p = 0.057

The adjusted mindfulness-use q-value is 0.0511 and the vitamins/minerals-use q-value is 0.0536, both just above the prespecified FDR prioritization threshold.

## Verification status

The final package was executed end-to-end from `CFS_JCM_public_data.csv`. The run reproduced all 123 model records, satisfied all structural invariants, and passed every table check at the printed precision, in addition to the selected headline checks. Full-precision results are in `analysis_outputs/cfs_results_full_precision.csv`; rounded display values are in `analysis_outputs/cfs_results_manuscript_ready.csv`.

The code and data release do not include the original parent-survey dataset or unrelated survey variables.


## Output guide

| Output | Contents |
|---|---|
| `analysis_outputs/tables/Table_1.csv` through `Table_5.csv` | Each manuscript table in its original row order |
| `analysis_outputs/tables/Tables_1_to_5.html` | Readable table document; open in a browser |
| `analysis_outputs/Figure_1.png` and `.pdf` | Recreated forest plot, with full plot source in `Build_Outputs.py` |
| `analysis_outputs/Figure_1_data.csv` | All plotted estimates, intervals, p/q values, and color classifications |
| `analysis_outputs/cfs_results_full_precision.csv` | All 123 adjusted and crude contrasts, event counts/denominators, p/q values, sparse-model triggers, convergence, VIFs |
| `analysis_outputs/cfs_results_manuscript_ready.csv` | Formatted results with model denominators |
| `analysis_outputs/cfs_missingness_by_model.csv` | Model eligibility and complete-case counts; `missing_n` primarily reflects survey routing, not unanswered eligible items |
| `analysis_outputs/cfs_participant_characteristics.csv` | Table 1 characteristics and tests |
| `analysis_outputs/all_manuscript_table_checks.csv` | Every numerical-cell and Firth-marker comparison with the reference manuscript |
| `analysis_outputs/public_data_checks.csv` | 158 data-schema, value, completeness, routing, and recoding checks |
| `analysis_outputs/cfs_invariant_checks.csv` | Structural, sample, model-count, and VIF checks |
| `analysis_outputs/denominator_ranges.csv` | Correct denominator ranges by model family/outcome |
| `analysis_outputs/findings_summary.csv` | Model counts and threshold findings by family/outcome |
| `analysis_outputs/repository_validation.json` | Machine-readable audit summary and source hashes |
| `analysis_outputs/cfs_run_metadata.json` | Software versions and frozen specification |

## Repository upload

Upload the extracted folder contents together so the relative paths remain intact. The ZIP may also be deposited as a supplementary reproducibility archive. Keep the data dictionary, README, code, references, and validation outputs with the data. This archive contains the full *analytic* dataset for this paper, not the unrelated fields from the parent survey. See `DATA_PROVENANCE.md` for the scope of deidentification and public-sharing authorization.

`SHA256SUMS.txt` fingerprints the distributed files, excluding itself. It describes the deposited release; rerunning code can change output bytes (for example, software-version metadata or PDF generation) even when all numerical checks pass.

No DOI, ORCID, or repository URL has been invented. Add the repository's persistent identifier to the manuscript's Data Availability Statement after deposit. No license is assigned by this package; the repository license should reflect the study team's actual sharing permissions.
