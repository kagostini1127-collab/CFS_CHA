#!/usr/bin/env python3
"""Generate Tables 1–5 and Figure 1 from fitted results; audit manuscript cells.

Reference numbers are used only for validation. Tables/plots use calculated
outputs, never substituted manuscript numbers. This script does not fit models.
"""
from __future__ import annotations
import argparse
import hashlib
import html
import json
import re
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import ScalarFormatter
import Analysis_CFS as analysis

ROOT = Path(__file__).resolve().parent


def probability(x):
    if pd.isna(x):
        return ''
    if x < .001:
        return '< 0.001'
    # Preserve the side of the .05 threshold, including vitamins/minerals.
    return f'{x:.4f}' if .045 <= x <= .055 else f'{x:.3f}'


def odds(r, prefix):
    if pd.isna(r[f'{prefix}_or']):
        return 'not estimable'
    def two(x):
        return str(Decimal(str(x)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))
    return (f"{two(r[f'{prefix}_or'])} "
            f"({two(r[f'{prefix}_ci_low'])}–{two(r[f'{prefix}_ci_high'])})")


def normalized(s):
    return re.sub(r'\s+', '', str(s)).replace(',', '').replace('–', '-').replace('−', '-')


def audit_cell(expected, observed):
    """Require agreement at the actual printed precision; no broad tolerances."""
    return normalized(expected) == normalized(observed)


def table1(raw, participant, reference):
    participant = participant.copy()
    participant['characteristic'] = participant.characteristic.ffill()
    # Empty CSV cells were parsed as NaN; characteristic ffill is intentional.
    aliases = {'Employment': 'Employment', 'Income': 'Poverty category',
               'Insurance': 'Health insurance', 'Region': 'U.S. region'}
    category_alias = {'Not working': 'Not working for pay',
                      'Part-time': 'Working part-time', 'Full-time': 'Working full-time',
                      'Above poverty': 'Above/not in poverty',
                      'Village or countryside': 'Village/countryside'}
    output, checks = [], []
    group = None
    for item in reference['rows']:
        expected = item['cells']
        label = expected[0]
        if label == 'All respondents':
            n = len(raw)
            n1 = int(raw.HXM_ChronicFatigueSyndrome.sum())
            observed = [label, f'{n-n1} ({(n-n1)/n*100:.1f})',
                        f'{n1} ({n1/n*100:.1f})', str(n), '']
        elif not expected[1]:
            group = aliases.get(label, label)
            r = participant.loc[participant.characteristic.eq(group)].iloc[0]
            observed = [label, '', '', '', probability(r.p_value)]
        else:
            cat = category_alias.get(label.strip(), label.strip())
            r = participant.loc[participant.characteristic.eq(group) & participant.category.eq(cat)].iloc[0]
            total = int(r.comparison_n + r.mecfs_n)
            observed = [label, f'{int(r.comparison_n)} ({r.comparison_percent:.1f})',
                        f'{int(r.mecfs_n)} ({r.mecfs_percent:.1f})',
                        f'{total} ({total/len(raw)*100:.1f})', '']
        output.append(observed)
        for j in range(1, 5):
            if expected[j]:
                checks.append({'table': 1, 'row': label, 'column': reference['columns'][j],
                               'manuscript': expected[j], 'reproduced': observed[j],
                               'passed': audit_cell(expected[j], observed[j])})
    return output, checks


def model_table(results, reference):
    output, checks = [], []
    number = reference['number']
    for item in reference['rows']:
        expected = item['cells']
        if 'key' not in item:
            output.append([expected[0]] + [''] * (len(expected)-1))
            continue
        r = results.loc[results.key.eq(item['key']) & results.outcome_type.eq(item['outcome_type'])].iloc[0]
        label = expected[0].replace(' †', '')
        if r.adjusted_method == 'Firth penalized logistic':
            label += ' †'
        observed = [label,
                    f'{int(r.comparison_events):,} ({r.comparison_percent:.1f})',
                    f'{int(r.case_events):,} ({r.case_percent:.1f})',
                    odds(r, 'unadjusted'), odds(r, 'adjusted'), probability(r.adjusted_p_value)]
        if number != 5:
            observed.append(probability(r.adjusted_q_value))
        output.append(observed)
        checks.append({'table': number, 'row': expected[0], 'column': 'Firth marker',
                       'manuscript': '†' in expected[0], 'reproduced': '†' in observed[0],
                       'passed': ('†' in expected[0]) == ('†' in observed[0])})
        for j in range(1, len(expected)):
            checks.append({'table': number, 'row': expected[0], 'column': reference['columns'][j],
                           'manuscript': expected[j], 'reproduced': observed[j],
                           'passed': audit_cell(expected[j], observed[j])})
    return output, checks


def make_figure(results, reference, destination):
    selected = [x for x in reference['rows'] if 'key' in x]
    fig, ax = plt.subplots(figsize=(12, 16))
    fig.subplots_adjust(left=.40, right=.77, top=.94, bottom=.10)
    colors = ['#193d6b', '#757b84', '#bdc4cd']
    coordinates = []
    for y, item in enumerate(reversed(selected)):
        r = results.loc[results.key.eq(item['key']) & results.outcome_type.eq('use')].iloc[0]
        color = colors[0] if r.adjusted_q_value < .05 else (colors[1] if r.adjusted_p_value < .05 else colors[2])
        composite = r.level == 'composite'
        ax.errorbar(r.adjusted_or, y,
                    xerr=[[r.adjusted_or-r.adjusted_ci_low], [r.adjusted_ci_high-r.adjusted_or]],
                    fmt='s' if composite else 'o', color=color, markersize=5, linewidth=1.5, capsize=0)
        label = item['cells'][0].replace(' †', '').strip()
        ax.text(-.035, y, label, transform=ax.get_yaxis_transform(), ha='right', va='center',
                fontsize=9, fontweight='bold' if composite else 'normal')
        ax.text(1.035, y, odds(r, 'adjusted'), transform=ax.get_yaxis_transform(), va='center',
                fontsize=9, fontweight='bold' if composite else 'normal')
        coordinates.append({'key': r.key, 'label': label, 'or': r.adjusted_or,
                            'ci_low': r.adjusted_ci_low, 'ci_high': r.adjusted_ci_high,
                            'p': r.adjusted_p_value, 'q': r.adjusted_q_value, 'color': color})
    ax.axvline(1, color='#9ca3af', linestyle='--', linewidth=1)
    ax.set_xscale('log')
    ax.set_xlim(.45, 10.2)
    ax.set_xticks([.5, 1, 2, 4, 8])
    ax.xaxis.set_major_formatter(ScalarFormatter())
    ax.set_ylim(-1, len(selected))
    ax.set_yticks([])
    ax.grid(axis='x', color='#e1e5eb', linewidth=.6)
    ax.set_axisbelow(True)
    for side in ['top', 'left', 'right']:
        ax.spines[side].set_visible(False)
    ax.set_xlabel('Adjusted odds ratio (log scale)', fontsize=10)
    fig.text(.04, .962, 'Complementary health approach', fontsize=12, weight='bold')
    fig.text(.79, .962, 'Adjusted OR (95% CI)', fontsize=12, weight='bold')
    fig.legend([Line2D([0], [0], marker='o', linestyle='', color=c) for c in colors],
               ['q < 0.05', 'p < 0.05; q ≥ 0.05', 'p ≥ 0.05'],
               loc='lower center', bbox_to_anchor=(.60, .035), ncol=3, frameon=False, fontsize=9)
    fig.text(.04, .018, 'Exploratory adjusted associations. * Excludes conventional physical therapy.', fontsize=9)
    fig.savefig(destination / 'Figure_1.png', dpi=300)
    fig.savefig(destination / 'Figure_1.pdf', metadata={'CreationDate': None, 'ModDate': None})
    plt.close(fig)
    pd.DataFrame(coordinates[::-1]).to_csv(destination/'Figure_1_data.csv', index=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT/'analysis_outputs')
    args = parser.parse_args()
    out = args.output_dir
    results = pd.read_csv(out/'cfs_results_full_precision.csv')
    raw = pd.read_csv(ROOT/'CFS_JCM_public_data.csv')
    participant = pd.read_csv(out/'cfs_participant_characteristics.csv')
    reference = json.loads((ROOT/'reference/manuscript_tables.json').read_text())
    tables = out/'tables'
    tables.mkdir(exist_ok=True)
    checks, html_parts = [], []
    titles = ['Participant characteristics', 'Complementary health approach use',
              'Favorability among users', 'Expected helpfulness for unused approaches',
              'Conventional comparators']
    for ref in reference['tables']:
        rows, audit = table1(raw, participant, ref) if ref['number'] == 1 else model_table(results, ref)
        checks.extend(audit)
        frame = pd.DataFrame(rows, columns=ref['columns'])
        frame.to_csv(tables/f'Table_{ref["number"]}.csv', index=False)
        html_parts.append(f'<h2>Table {ref["number"]}. {titles[ref["number"]-1]}</h2>'+frame.to_html(index=False, escape=True))
    pd.DataFrame(checks).to_csv(out/'all_manuscript_table_checks.csv', index=False)
    (tables/'Tables_1_to_5.html').write_text(
        '<!doctype html><html lang="en"><meta charset="utf-8"><title>ME/CFS manuscript tables</title>'
        '<style>body{font:14px Arial;margin:32px;color:#18212b}table{border-collapse:collapse;width:100%;margin-bottom:28px}'
        'td,th{border-bottom:1px solid #d5dbe3;padding:7px;text-align:left}th{background:#edf2f7}'
        'h2{margin-top:36px}@media print{h2{break-before:page}tr{break-inside:avoid}}</style>'
        '<h1>ME/CFS manuscript tables</h1><p>Calculated directly from the public analytic data. '
        'Counts are positive outcomes; percentages use the eligible denominator. '
        '† indicates Firth penalization with profile-likelihood confidence intervals. '
        '* indicates stimulation other than conventional physical therapy. '
        'Tables 2–4: q values use all 102 adjusted CHA models. Table 5: nominal p values only. '
        'Model-specific denominators and full-precision results accompany these tables.</p>'
        + ''.join(html_parts)+'</html>', encoding='utf-8')
    make_figure(results, reference['tables'][1], out)
    denominator_ranges = results.groupby(['family', 'outcome_type']).n.agg(['min', 'max'])
    denominator_ranges.to_csv(out/'denominator_ranges.csv')
    findings = []
    for family in ['CHA', 'conventional']:
        for kind in ['use', 'fav', 'expect']:
            r = results.loc[results.family.eq(family) & results.outcome_type.eq(kind)]
            column = 'adjusted_q_value' if family == 'CHA' else 'adjusted_p_value'
            findings.append({'family':family, 'outcome_type':kind, 'models':len(r),
                             'below_0_05':int((r[column] < .05).sum()), 'criterion':column,
                             'minimum_denominator':int(r.n.min()), 'maximum_denominator':int(r.n.max())})
    pd.DataFrame(findings).to_csv(out/'findings_summary.csv', index=False)
    summary = {'table_cells_checked':len(checks), 'table_checks_passed':all(c['passed'] for c in checks),
               'failed_table_checks':sum(not c['passed'] for c in checks),
               'adjusted_models_converged':bool(results.adjusted_converged.all()),
               'firth_profile_intervals':int(results.adjusted_ci_type.eq('profile penalized likelihood').sum()),
               'maximum_design_VIF':float(results.adjusted_max_vif.max()),
               'maximum_exposure_VIF':float(results.adjusted_focal_vif.max()),
               'source_manuscript':reference['source_manuscript'],
               'source_manuscript_sha256':reference['sha256'],
               'data_sha256':hashlib.sha256((ROOT/'CFS_JCM_public_data.csv').read_bytes()).hexdigest(),
               'known_prose_correction':'Methods denominator ranges require correction; see MANUSCRIPT_RECONCILIATION.md.'}
    (out/'repository_validation.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))
    if not summary['table_checks_passed']:
        failed = pd.DataFrame(checks).loc[lambda x:~x.passed]
        print(failed.to_string(index=False))
        raise SystemExit('Manuscript table audit failed. Inspect all_manuscript_table_checks.csv.')


if __name__ == '__main__':
    main()
