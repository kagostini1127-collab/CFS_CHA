#!/usr/bin/env python3
"""Recompute all models, regenerate tables/figure, and audit the manuscript."""
from __future__ import annotations
import os
# Avoid excessive BLAS threads for small regression matrices.
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
import pandas as pd
import Analysis_CFS as analysis

ROOT = Path(__file__).resolve().parent


def preflight(out):
    raw = pd.read_csv(ROOT/'CFS_JCM_public_data.csv')
    manifest = pd.read_csv(ROOT/'CFS_JCM_variable_manifest.csv')
    levels = {
        'HXM_ChronicFatigueSyndrome': [0,1], 'AGECAT1': [1,2,3,4],
        'RACE2': [1,2,3,4,5], 'RACE_4Level': [1,2,3,4], 'BMI_Category': [1,2,3,4],
        'SEX2': [0,1], 'EDUCATION_2LEVEL': [0,1], 'COMMSIZE_3Level': [1,2,3],
        'EMPLOYM': [0,1,2], 'POVERTYCAT': [1,2,3], 'Region': [1,2,3,4],
        'insurance_corrected': [0,1]}
    allowed = list(levels) + [c for m in analysis.MODALITIES.values() for c in m[3:]]
    checks = []
    def check(name, passed, observed=''):
        checks.append({'check':name, 'passed':bool(passed), 'observed':str(observed)})
    check('exact_117_column_whitelist', len(raw.columns)==117 and set(raw.columns)==set(allowed))
    check('manifest_covers_exactly_all_columns', len(manifest)==117 and set(manifest.variable)==set(allowed))
    check('analytic_sample', raw.shape==(3022,117), raw.shape)
    check('exposure_counts', raw.HXM_ChronicFatigueSyndrome.value_counts().to_dict()=={0:2855,1:167})
    check('all_fields_numeric', all(pd.api.types.is_numeric_dtype(t) for t in raw.dtypes))
    for col, values in levels.items():
        check(col+'_complete_and_valid', raw[col].notna().all() and raw[col].isin(values).all())
    check('race_recode_consistent', raw.RACE2.map({2:1,3:2,4:3,1:4,5:4}).equals(raw.RACE_4Level))
    for key, m in analysis.MODALITIES.items():
        use, fav, exp = m[3:]
        check(key+'_use_complete_and_binary', raw[use].notna().all() and raw[use].isin([0,1]).all())
        check(key+'_ratings_valid', raw[fav].dropna().isin(range(1,7)).all() and raw[exp].dropna().isin(range(1,7)).all())
        check(key+'_routing', raw.loc[raw[use].eq(0),fav].isna().all() and raw.loc[raw[use].eq(1),exp].isna().all())
        check(key+'_eligible_ratings_complete', raw.loc[raw[use].eq(1),fav].notna().all() and raw.loc[raw[use].eq(0),exp].notna().all())
    pd.DataFrame(checks).to_csv(out/'public_data_checks.csv', index=False)
    if not all(x['passed'] for x in checks):
        print(pd.DataFrame(checks).loc[lambda x:~x.passed].to_string(index=False))
        raise SystemExit('Input checks failed. No models were fitted.')
    return len(checks)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT/'analysis_outputs')
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    nchecks = preflight(out)
    print(f'Passed {nchecks} public-data checks; fitting 123 models...', flush=True)
    command = [sys.executable, str(ROOT/'Analysis_CFS.py'), '--data', str(ROOT/'CFS_JCM_public_data.csv'),
               '--spec', str(ROOT/'Analysis_Config_CFS.json'), '--output-dir', str(out)]
    completed = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out/'analysis_run.log').write_text(completed.stdout)
    print(completed.stdout, flush=True)
    if completed.returncode:
        raise SystemExit(completed.returncode)
    invariants = pd.read_csv(out/'cfs_invariant_checks.csv')
    results = pd.read_csv(out/'cfs_results_full_precision.csv')
    if not invariants.passed.all() or not results.adjusted_converged.all():
        raise SystemExit('A model or invariant failed; inspect analysis outputs.')
    firth = results.loc[results.adjusted_method.eq('Firth penalized logistic')]
    if len(firth)!=20 or not firth.adjusted_ci_type.eq('profile penalized likelihood').all():
        raise SystemExit('Firth interval/count validation failed.')
    subprocess.run([sys.executable, str(ROOT/'Build_Outputs.py'), '--output-dir', str(out)], check=True)
    print('PASS: all 123 models and all 949 manuscript table checks. See MANUSCRIPT_RECONCILIATION.md for the prose denominator correction.')


if __name__ == '__main__':
    main()
