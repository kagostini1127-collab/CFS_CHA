#!/usr/bin/env python3
"""Reproducible ME/CFS complementary-health-approach analysis for JCM.

This script implements the frozen analysis specification used for:

    Complementary Health Approach Use and Treatment-Seeking Patterns among
    U.S. Adults Reporting Clinician-Diagnosed ME/CFS: A Quota-Sampled
    Cross-Sectional Survey

It reads the de-identified public CSV bundled with this repository,
reconstructs all intervention and category outcomes, derives the covariates
used in the final manuscript, fits the complete 123-model inventory, applies
Firth penalization under the prespecified sparse-data triggers, and applies
BH-FDR correction across the 102 CHA models.

The public CSV contains only variables required for this paper; direct
identifiers, Qualtrics administrative fields, free text, unrelated diagnoses,
and unrelated psychometric scales are not included.
"""

from __future__ import annotations

import argparse
import warnings
import json
import math
import platform
import sys
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import numpy as np
import pandas as pd
warnings.filterwarnings("ignore", category=pd.errors.PerformanceWarning)
import scipy
from scipy.optimize import brentq
from scipy.special import expit
from scipy.stats import chi2, chi2_contingency, fisher_exact, norm


# ---------------------------------------------------------------------------
# Intervention inventory
# ---------------------------------------------------------------------------

MODALITIES = {
    "VITSUPPL": ("Vitamins or minerals", "CHA", "nutritional", "CHAUSE_VITSUPPL", "FAV_VITSUPPL", "EXPECTVITSUPPL"),
    "OTHERSUPPL": ("Other dietary supplements or natural products", "CHA", "nutritional", "CHAUSE_OTHERSUPPL", "FAV_OTHERSUPPL", "EXPECTOTHERSUPPL"),
    "HERBALIST": ("Herbalist consultation", "CHA", "nutritional", "CHAUSE_HERBALIST", "FAV_HERBALIST", "EXPECTHERBALIST"),
    "NONRXDIET": ("Self-directed special diet", "CHA", "nutritional", "CHAUSE_NONRXDIET", "FAV_NONRXDIET", "EXPECTNONRXDIET"),
    "HOMEOPATH": ("Homeopathy", "CHA", "nutritional", "CHAUSE_HOMEOPATH", "FAV_HOMEOPATH", "EXPECTHOMEOPATH"),
    "CHIROPRACTIC": ("Chiropractic care", "CHA", "physical", "CHAUSE_CHIROPRACTIC", "FAV_CHIROPRACTIC", "EXPECTCHIROPRACTIC"),
    "OSTEOPATHIC": ("Osteopathic manipulation", "CHA", "physical", "CHAUSE_OSTEOPATHIC", "FAV_OSTEOPATHIC", "EXPECTOSTEOPATHIC"),
    "MASSAGE": ("Massage therapy", "CHA", "physical", "CHAUSE_MASSAGE", "FAV_MASSAGE", "EXPECTMASSAGE"),
    "ALTPHYSICAL": ("Light, magnetic, or electrical stimulation other than physical therapy", "CHA", "physical", "CHAUSE_ALTPHYSICAL", "FAV_ALTPHYSICAL", "EXPECTALTPHYSICAL"),
    "DEVICES": ("Other nonconventional devices", "CHA", "physical", "CHAUSE_DEVICES", "FAV_DEVICES", "EXPECTDEVICES"),
    "SPIRITHEAL": ("Spiritual healing", "CHA", "psychological", "CHAUSE_SPIRITHEAL", "FAV_SPIRITHEAL", "EXPECTSPIRITHEAL"),
    "PRAYER": ("Prayer", "CHA", "psychological", "CHAUSE_PRAYER", "FAV_PRAYER", "EXPECTPRAYER"),
    "MINDFUL": ("Mindfulness", "CHA", "psychological", "CHAUSE_MINDFUL", "FAV_MINDFUL", "EXPECTMINDFUL"),
    "SHAMANIC": ("Shamanic journey", "CHA", "psychological", "CHAUSE_SHAMANIC", "FAV_SHAMANIC", "EXPECTSHAMANIC"),
    "HYPNOTHER": ("Guided hypnosis", "CHA", "psychological", "CHAUSE_HYPNOTHER", "FAV_HYPNOTHER", "EXPECTHYPNOTHERAPY"),
    "SELFHYPNO": ("Self-hypnosis", "CHA", "psychological", "CHAUSE_SELFHYPNO", "FAV_SELFHYPNO", "EXPECTSELFHYPNOSIS"),
    "BREATHING": ("Deep breathing exercises", "CHA", "combined", "CHAUSE_BREATHING", "FAV_BREATHING", "EXPECTBREATHING"),
    "RELAXATION": ("Progressive relaxation", "CHA", "combined", "CHAUSE_RELAXATION", "FAV_RELAXATION", "EXPECTRELAXATION"),
    "MEDITATION": ("Meditation", "CHA", "combined", "CHAUSE_MEDITATION", "FAV_MEDITATION", "EXPECTMEDITATION"),
    "BIOFEED": ("Biofeedback", "CHA", "combined", "CHAUSE_BIOFEED", "FAV_BIOFEED", "EXPECTBIOFEEDBACK"),
    "IMAGERY": ("Guided imagery", "CHA", "combined", "CHAUSE_IMAGERY", "FAV_IMAGERY", "EXPECTIMAGERY"),
    "ACUPUNCTURE": ("Acupuncture", "CHA", "combined", "CHAUSE_ACUPUNCTURE", "FAV_ACUPUNCTURE", "EXPECTACUPUNCTURE"),
    "YOGA": ("Yoga", "CHA", "combined", "CHAUSE_YOGA", "FAV_YOGA", "EXPECTYOGA"),
    "TAICHI": ("Tai chi or qigong", "CHA", "combined", "CHAUSE_TAICHI", "FAV_TAICHI", "EXPECTAICHI"),
    "MOVEMENT": ("Movement therapy", "CHA", "combined", "CHAUSE_MOVEMENT", "FAV_MOVEMENT", "EXPECTMOVEMENT"),
    "ARTS": ("Art, music, or dance therapy", "CHA", "combined", "CHAUSE_ARTS", "FAV_ARTS", "EXPECTARTS"),
    "TRADITIONAL": ("Traditional healing systems", "CHA", "systems", "CHAUSE_TRADITIONAL", "FAV_TRADITIONAL", "EXPECTTRADITIONAL"),
    "NATUROPATH": ("Naturopathy", "CHA", "systems", "CHAUSE_NATUROPATH", "FAV_NATUROPATH", "EXPECTNATUROPATH"),
    "HOTCOLD": ("Heat or cold therapy", "conventional", "", "CHAUSE_HOTCOLD", "FAV_HOTCOLD", "EXPECTHOTCOLD"),
    "OTCMED": ("Over-the-counter medication", "conventional", "", "CHAUSE_OTCMED", "FAV_NONRXMED", "EXPECTNONRXMED"),
    "PHYSTHERAPY": ("Physical therapy", "conventional", "", "CHAUSE_PHYSTHERAPY", "FAV_PHYSTHERAPY", "EXPECTPHYSTHERAPY"),
    "PSYCHOTHER": ("Psychotherapy", "conventional", "", "CHAUSE_PSYCHOTHER", "FAV_PSYCHOTHER", "EXPECTPSYCHOTHER"),
    "RXDIET": ("Prescription diet", "conventional", "", "CHAUSE_RXDIET", "FAV_RXDIET", "EXPECTRXDIET"),
    "RXMED": ("Prescription medication", "conventional", "", "CHAUSE_RXMED", "FAV_RXMED", "EXPECTRXMED"),
    "SURGERY": ("Surgery", "conventional", "", "CHAUSE_SURGERY", "FAV_SURGERY", "EXPECTSURGERY"),
}

CATEGORY_KEYS = {
    "nutritional": [k for k, v in MODALITIES.items() if v[1:3] == ("CHA", "nutritional")],
    "physical": [k for k, v in MODALITIES.items() if v[1:3] == ("CHA", "physical")],
    "psychological": [k for k, v in MODALITIES.items() if v[1:3] == ("CHA", "psychological")],
    "combined": [k for k, v in MODALITIES.items() if v[1:3] == ("CHA", "combined")],
    "systems": [k for k, v in MODALITIES.items() if v[1:3] == ("CHA", "systems")],
}
CHA_KEYS = [k for k, v in MODALITIES.items() if v[1] == "CHA"]
CONVENTIONAL_KEYS = [k for k, v in MODALITIES.items() if v[1] == "conventional"]


# ---------------------------------------------------------------------------
# Data loading and variable resolution
# ---------------------------------------------------------------------------

def load_data(csv_path: Path) -> tuple[pd.DataFrame, dict]:
    """Read the de-identified public-use CSV bundled with this package."""
    df = pd.read_csv(csv_path)
    return df, {"reader": "pandas.read_csv", "source_file": csv_path.name}

def resolve_exposure_column(df: pd.DataFrame, spec: dict) -> str:
    exp = spec["exposure"]
    candidates = [exp.get("variable")] + list(exp.get("variable_candidates", []))
    candidates = [x for x in candidates if x]
    for candidate in candidates:
        if candidate in df.columns:
            return candidate

    # Defensive fallback for source files in which the exported variable name
    # differs slightly but remains clearly identifiable.
    normalized = []
    for col in df.columns:
        s = str(col).lower().replace("_", "").replace("/", "")
        if str(col).startswith("HXM_") and "chronic" in s and "fatigue" in s:
            normalized.append(str(col))
        elif str(col).startswith("HXM_") and s.endswith("cfs"):
            normalized.append(str(col))
    normalized = sorted(set(normalized))
    if len(normalized) == 1:
        return normalized[0]
    raise KeyError(
        "Could not uniquely resolve the chronic-fatigue-syndrome exposure variable. "
        f"Tried {candidates}; HXM-like fallback matches were {normalized}."
    )


# ---------------------------------------------------------------------------
# Outcome and covariate construction
# ---------------------------------------------------------------------------

def derive_covariates(d: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    """Create the covariates used in the final CFS/JCM models.

    The preserved dataset contains categorical analysis fields used by the
    historical CFS pipeline. These are preferred because they reproduce the
    exact factor coding. Continuous/raw fallbacks are used only when a
    categorical field is absent, and the fallback is recorded in QA output.
    """
    d = d.copy()
    checks: list[dict] = []

    # The public release already contains the corrected insurance covariate:
    # public OR private coverage = 1, uninsured = 0. The three source insurance
    # columns from the master file are intentionally not published.
    if "insurance_corrected" not in d.columns:
        raise KeyError("Public dataset is missing insurance_corrected")
    d["insurance_corrected"] = pd.to_numeric(d["insurance_corrected"], errors="coerce")

    # Age: prefer the historical four-level AGECAT1 field.
    if "AGECAT1" in d.columns:
        d["age4"] = pd.to_numeric(d["AGECAT1"], errors="coerce")
        age_source = "AGECAT1"
    else:
        d["age4"] = pd.cut(
            d["AGE"], bins=[-np.inf, 34, 49, 64, np.inf],
            labels=[1, 2, 3, 4], right=True
        ).astype(float)
        age_source = "derived from AGE"

    # Regression race uses four levels with the verified public-data coding:
    # 1=White/Caucasian non-Hispanic, 2=Black/African American non-Hispanic,
    # 3=Hispanic, 4=all other race/ethnicity responses. Table 1 retains the
    # original five-level RACE2 variable for transparency.
    if "RACE_4Level" in d.columns:
        d["race4"] = pd.to_numeric(d["RACE_4Level"], errors="coerce")
        race_source = "RACE_4Level"
    else:
        race_map = {2: 1, 3: 2, 4: 3, 1: 4, 5: 4}
        d["race4"] = d["RACE2"].map(race_map).astype(float)
        race_source = "derived from RACE2"

    # BMI: prefer the stored four-level BMI_Category field, with normal BMI
    # (level 2) as reference.
    if "BMI_Category" in d.columns:
        d["bmi4"] = pd.to_numeric(d["BMI_Category"], errors="coerce")
        bmi_source = "BMI_Category"
    else:
        d["bmi4"] = pd.cut(
            d["BMIadjusted"], bins=[-np.inf, 18.5, 25.0, 30.0, np.inf],
            labels=[1, 2, 3, 4], right=False
        ).astype(float)
        bmi_source = "derived from BMIadjusted"

    checks.extend([
        {"check": "age_covariate_source", "passed": True, "observed": age_source},
        {"check": "race_covariate_source", "passed": True, "observed": race_source},
        {"check": "bmi_covariate_source", "passed": True, "observed": bmi_source},
        {"check": "age_levels_valid", "passed": bool(d["age4"].dropna().isin([1, 2, 3, 4]).all())},
        {"check": "race4_levels_valid", "passed": bool(d["race4"].dropna().isin([1, 2, 3, 4]).all())},
        {"check": "bmi4_levels_valid", "passed": bool(d["bmi4"].dropna().isin([1, 2, 3, 4]).all())},
    ])
    return d, checks


def rebuild_outcomes(d: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    checks: list[dict] = []
    d = d.copy()

    for key, (_, _, _, use, fav, exp) in MODALITIES.items():
        required = [use, fav, exp]
        missing = [x for x in required if x not in d.columns]
        if missing:
            raise KeyError(f"Missing source variables for {key}: {missing}")
        d[f"use__{key}"] = d[use]
        d[f"fav__{key}"] = np.where(
            d[use].eq(1) & d[fav].notna(), (d[fav] > 3.5).astype(float), np.nan
        )
        d[f"expect__{key}"] = np.where(
            d[use].eq(0) & d[exp].notna(), (d[exp] > 3.5).astype(float), np.nan
        )
        checks.append({
            "check": f"{key}_rating_range",
            "passed": bool(
                d[fav].dropna().between(1, 6).all()
                and d[exp].dropna().between(1, 6).all()
            ),
        })

    for category, keys in {"overall": CHA_KEYS, **CATEGORY_KEYS}.items():
        uses = [MODALITIES[k][3] for k in keys]
        favs = [MODALITIES[k][4] for k in keys]
        exps = [MODALITIES[k][5] for k in keys]

        used = d[uses].max(axis=1, skipna=True)
        d[f"use__{category}"] = used

        # Composite favorability averages only ratings for modalities the
        # respondent actually used. Composite expectation averages only ratings
        # for modalities the respondent did not use. A respondent can therefore
        # contribute to both a category's favorability and expectation outcomes
        # when they used some constituent modalities but not others.
        fav_parts = []
        exp_parts = []
        for k in keys:
            use_col = MODALITIES[k][3]
            fav_col = MODALITIES[k][4]
            exp_col = MODALITIES[k][5]
            fav_parts.append(d[fav_col].where(d[use_col].eq(1)))
            exp_parts.append(d[exp_col].where(d[use_col].eq(0)))
        fav_mean = pd.concat(fav_parts, axis=1).mean(axis=1, skipna=True)
        exp_mean = pd.concat(exp_parts, axis=1).mean(axis=1, skipna=True)
        d[f"fav__{category}"] = np.where(
            fav_mean.notna(), (fav_mean >= 3.5).astype(float), np.nan
        )
        d[f"expect__{category}"] = np.where(
            exp_mean.notna(), (exp_mean >= 3.5).astype(float), np.nan
        )

    stored = {
        "overall": "USE_ANYCHAALL",
        "nutritional": "USE_ANYCHANUTRITIONAL",
        "physical": "USE_ANYCHAPHYSICAL",
        "psychological": "USE_ANYCHAPSYCH",
        "combined": "USE_ANYCHACOMBINED",
        "systems": "USE_ANYCHASYSTEMS",
    }
    for category, col in stored.items():
        if col in d.columns:
            checks.append({
                "check": f"reconstructed_{category}_use_matches_stored",
                "passed": bool(d[f"use__{category}"].eq(d[col]).all()),
            })

    return d, checks


def add_dummies(
    frame: pd.DataFrame, source: pd.Series, prefix: str, levels: list, reference
) -> pd.DataFrame:
    for level in levels:
        if level != reference:
            frame[f"{prefix}_{level:g}"] = source.eq(level).astype(float)
    return frame


def design_frame(d: pd.DataFrame) -> pd.DataFrame:
    z = pd.DataFrame(index=d.index)
    z["mecfs"] = d["mecfs"]
    z["insurance"] = d["insurance_corrected"]
    z["sex_female"] = d["SEX2"]
    # EDUCATION_2LEVEL is already binary in the historical CFS pipeline.
    z["education_some_college_or_more"] = d["EDUCATION_2LEVEL"]
    z = add_dummies(z, d["age4"], "age", [1, 2, 3, 4], 1)
    z = add_dummies(z, d["race4"], "race", [1, 2, 3, 4], 1)
    z = add_dummies(z, d["COMMSIZE_3Level"], "residence", [1, 2, 3], 1)
    z = add_dummies(z, d["EMPLOYM"], "employment", [0, 1, 2], 0)
    z = add_dummies(z, d["POVERTYCAT"], "poverty", [1, 2, 3], 1)
    z = add_dummies(z, d["Region"], "region", [1, 2, 3, 4], 1)
    z = add_dummies(z, d["bmi4"], "bmi", [1, 2, 3, 4], 2)
    return z


# ---------------------------------------------------------------------------
# Logistic regression and Firth implementation
# ---------------------------------------------------------------------------

def loglik(beta: np.ndarray, X: np.ndarray, y: np.ndarray) -> float:
    eta = X @ beta
    return float(y @ eta - np.logaddexp(0, eta).sum())


def ml_fit(X: np.ndarray, y: np.ndarray) -> dict:
    beta = np.zeros(X.shape[1])
    converged = False
    for _ in range(100):
        p = expit(X @ beta)
        w = np.clip(p * (1 - p), 1e-10, None)
        info = X.T @ (X * w[:, None])
        step = np.linalg.pinv(info) @ (X.T @ (y - p))
        old = loglik(beta, X, y)
        scale = 1.0
        while scale > 1e-8 and loglik(beta + scale * step, X, y) < old:
            scale /= 2
        beta = beta + scale * step
        # A sparse nuisance direction can keep the Newton step large even after
        # the likelihood score is effectively zero. Accept score convergence as
        # well as step convergence so a stable focal estimate is not spuriously
        # sent to the Firth fallback.
        score = X.T @ (y - expit(X @ beta))
        if np.max(np.abs(scale * step)) < 1e-8 or np.max(np.abs(score)) < 1e-8:
            converged = True
            break
    p = expit(X @ beta)
    info = X.T @ (X * (p * (1 - p))[:, None])
    cov = np.linalg.pinv(info)
    se = np.sqrt(np.maximum(np.diag(cov), 0))
    return {
        "beta": beta,
        "se": se,
        "ll": loglik(beta, X, y),
        "converged": converged,
        "message": "Newton-Raphson/IRLS",
        "cov": cov,
    }


def firth_loglik(beta: np.ndarray, X: np.ndarray, y: np.ndarray) -> float:
    p = expit(X @ beta)
    info = X.T @ (X * (p * (1 - p))[:, None])
    sign, ld = np.linalg.slogdet(info)
    if sign <= 0 or not np.isfinite(ld):
        return -1e100
    return loglik(beta, X, y) + 0.5 * ld


def firth_fit(
    X: np.ndarray,
    y: np.ndarray,
    start: np.ndarray | None = None,
    fixed: dict[int, float] | None = None,
) -> dict:
    if start is None or not np.isfinite(start).all():
        start = np.zeros(X.shape[1])
    beta = start.copy()
    fixed = fixed or {}
    for idx, value in fixed.items():
        beta[idx] = value
    free = [i for i in range(X.shape[1]) if i not in fixed]
    converged = False

    for _ in range(250):
        p = expit(X @ beta)
        w = np.clip(p * (1 - p), 1e-10, None)
        info = X.T @ (X * w[:, None])
        inv = np.linalg.pinv(info)
        hat = w * np.einsum("ij,jk,ik->i", X, inv, X)
        adjusted_score = X[:, free].T @ (y - p + hat * (0.5 - p))
        info_free = X[:, free].T @ (X[:, free] * w[:, None])
        step = np.linalg.pinv(info_free) @ adjusted_score
        old = firth_loglik(beta, X, y)
        scale = 1.0
        candidate = beta.copy()
        candidate[free] += step
        while scale > 1e-8 and firth_loglik(candidate, X, y) < old:
            scale /= 2
            candidate = beta.copy()
            candidate[free] += scale * step
        beta = candidate
        if np.max(np.abs(scale * step)) < 1e-7:
            converged = True
            break

    p = expit(X @ beta)
    info = X.T @ (X * (p * (1 - p))[:, None])
    cov = np.linalg.pinv(info)
    se = np.sqrt(np.maximum(np.diag(cov), 0))
    return {
        "beta": beta,
        "se": se,
        "ll": firth_loglik(beta, X, y),
        "converged": converged,
        "message": "Firth adjusted-score iteration",
        "cov": cov,
    }


def profile_firth_ci(
    X: np.ndarray, y: np.ndarray, fit: dict, idx: int = 1
) -> tuple[float, float]:
    target = fit["ll"] - chi2.ppf(0.95, 1) / 2

    def prof(value: float) -> float:
        constrained = firth_fit(X, y, fit["beta"], fixed={idx: value})
        return constrained["ll"] - target

    center = fit["beta"][idx]
    step = max(float(fit["se"][idx]), 0.25)

    def bracket(direction: int):
        inner = center
        outer = center + direction * step
        for _ in range(20):
            if prof(outer) <= 0:
                return (outer, inner) if direction < 0 else (inner, outer)
            inner = outer
            outer = center + direction * abs(outer - center) * 1.8
        raise RuntimeError("Could not bracket Firth profile interval")

    lo = brentq(prof, *bracket(-1), xtol=1e-5)
    hi = brentq(prof, *bracket(1), xtol=1e-5)
    return lo, hi


def vif_values(X: np.ndarray, names: list[str]) -> dict:
    out = {}
    for j in range(1, X.shape[1]):
        y = X[:, j]
        others = np.delete(X, j, axis=1)
        beta = np.linalg.lstsq(others, y, rcond=None)[0]
        resid = y - others @ beta
        sst = ((y - y.mean()) ** 2).sum()
        r2 = 1 - (resid @ resid) / sst if sst > 0 else 1.0
        out[names[j]] = float(1 / max(1 - r2, 1e-12))
    return out


def two_by_two(d: pd.DataFrame, outcome: str) -> dict:
    q = d[["mecfs", outcome]].dropna()
    tab = pd.crosstab(q["mecfs"], q[outcome]).reindex(
        index=[0, 1], columns=[0, 1], fill_value=0
    )
    obs = tab.to_numpy()
    _, p_pearson, _, expected = chi2_contingency(obs, correction=False)
    _, p_yates, _, _ = chi2_contingency(obs, correction=True)
    p_fisher = fisher_exact(obs)[1]
    use_fisher = bool((expected < 5).any())
    return {
        "n": len(q),
        "comparison_n": int(obs[0].sum()),
        "case_n": int(obs[1].sum()),
        "comparison_events": int(obs[0, 1]),
        "case_events": int(obs[1, 1]),
        "comparison_percent": float(obs[0, 1] / obs[0].sum() * 100),
        "case_percent": float(obs[1, 1] / obs[1].sum() * 100),
        "p_pearson": float(p_pearson),
        "p_yates": float(p_yates),
        "p_fisher": float(p_fisher),
        "bivariate_test": "Fisher exact" if use_fisher else "Pearson chi-square",
        "bivariate_p": float(p_fisher if use_fisher else p_pearson),
        "min_cell": int(obs.min()),
        "min_expected": float(expected.min()),
    }


def fit_model(d: pd.DataFrame, outcome: str, adjusted: bool) -> dict:
    z = design_frame(d) if adjusted else d[["mecfs"]]
    q = pd.concat([d[[outcome]], z], axis=1).dropna()
    y = q[outcome].to_numpy(float)
    names = ["intercept"] + list(z.columns)
    X = np.column_stack([np.ones(len(q)), q[z.columns].to_numpy(float)])

    ml = ml_fit(X, y)
    idx = names.index("mecfs")
    beta, se = ml["beta"][idx], ml["se"][idx]
    lo = beta - 1.95996398454 * se
    hi = beta + 1.95996398454 * se

    tab = two_by_two(d, outcome)

    if not adjusted:
        # With a single binary exposure, the ordinary unadjusted logistic OR is
        # exactly the 2x2 cross-product ratio. Compute it directly so displayed
        # crude estimates are deterministic and do not depend on iterative
        # optimizer tolerances. Zero-cell contrasts remain not estimable.
        a = tab["case_events"]
        b = tab["case_n"] - tab["case_events"]
        c = tab["comparison_events"]
        d0 = tab["comparison_n"] - tab["comparison_events"]
        if min(a, b, c, d0) == 0:
            return {
                "n_model": int(len(q)), "events": int(y.sum()),
                "method": "ordinary unadjusted logistic (not estimable: zero cell)",
                "firth_trigger": "zero exposure-by-outcome cell",
                "converged": False, "or": np.nan, "ci_low": np.nan,
                "ci_high": np.nan, "ci_type": "not estimable",
                "p_value": np.nan, "focal_vif": 1.0, "max_vif": 1.0,
                "max_vif_term": "mecfs",
            }
        crude_or = (a * d0) / (b * c)
        crude_beta = math.log(crude_or)
        crude_se = math.sqrt(1/a + 1/b + 1/c + 1/d0)
        crude_lo = math.exp(crude_beta - 1.95996398454 * crude_se)
        crude_hi = math.exp(crude_beta + 1.95996398454 * crude_se)
        crude_p = float(2 * norm.sf(abs(crude_beta / crude_se)))
        return {
            "n_model": int(len(q)), "events": int(y.sum()),
            "method": "ordinary unadjusted logistic", "firth_trigger": "",
            "converged": True, "or": float(crude_or),
            "ci_low": float(crude_lo), "ci_high": float(crude_hi),
            "ci_type": "Wald", "p_value": crude_p,
            "focal_vif": 1.0, "max_vif": 1.0, "max_vif_term": "mecfs",
        }

    ratio = math.exp(hi - lo) if np.isfinite(hi - lo) and hi - lo < 700 else math.inf
    triggers = []
    if tab["min_cell"] < 5:
        triggers.append("exposure-by-outcome cell <5")
    if not ml["converged"]:
        triggers.append("ML nonconvergence")
    if not np.isfinite(beta) or abs(beta) > 20:
        triggers.append("separation/unstable coefficient")
    if ratio > 50:
        triggers.append("CI upper/lower ratio >50")

    method = "maximum likelihood logistic"
    fit = ml
    p_value = float(2 * norm.sf(abs(beta / se))) if se > 0 else np.nan
    ci_type = "Wald"

    if adjusted and triggers:
        method = "Firth penalized logistic"
        fit = firth_fit(X, y, ml["beta"])
        beta, se = fit["beta"][idx], fit["se"][idx]
        try:
            lo, hi = profile_firth_ci(X, y, fit, idx)
            ci_type = "profile penalized likelihood"
        except Exception:
            lo = beta - 1.95996398454 * se
            hi = beta + 1.95996398454 * se
            ci_type = "Wald fallback after failed profile"
            triggers.append("profile CI fallback")
        null = firth_fit(X, y, fit["beta"], fixed={idx: 0.0})
        p_value = float(chi2.sf(max(0.0, 2 * (fit["ll"] - null["ll"])), 1))

    vifs = vif_values(X, names) if adjusted else {"mecfs": 1.0}
    return {
        "n_model": int(len(q)),
        "events": int(y.sum()),
        "method": method,
        "firth_trigger": "; ".join(triggers),
        "converged": bool(fit["converged"]),
        "or": float(math.exp(beta)),
        "ci_low": float(math.exp(lo)),
        "ci_high": float(math.exp(hi)),
        "ci_type": ci_type,
        "p_value": p_value,
        "focal_vif": float(vifs.get("mecfs", np.nan)),
        "max_vif": float(max(vifs.values())),
        "max_vif_term": max(vifs, key=vifs.get),
    }


def bh_adjust(pvalues: pd.Series) -> pd.Series:
    p = pvalues.to_numpy(float)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * len(p) / np.arange(1, len(p) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty_like(q)
    out[order] = np.minimum(q, 1)
    return pd.Series(out, index=pvalues.index)


# ---------------------------------------------------------------------------
# Analysis inventory and output tables
# ---------------------------------------------------------------------------

def outcome_inventory() -> list[dict]:
    items = []
    for key, label in [
        ("overall", "Any CHA"),
        ("nutritional", "Any nutritional CHA"),
        ("physical", "Any physical CHA"),
        ("psychological", "Any psychological CHA"),
        ("combined", "Any combined CHA"),
        ("systems", "Any systems approach"),
    ]:
        items.append({"key": key, "label": label, "family": "CHA", "level": "composite"})
    for key in CHA_KEYS:
        items.append({"key": key, "label": MODALITIES[key][0], "family": "CHA", "level": "individual"})
    for key in CONVENTIONAL_KEYS:
        items.append({"key": key, "label": MODALITIES[key][0], "family": "conventional", "level": "individual"})
    return items


def run_analysis(d: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    missing = []

    for item in outcome_inventory():
        for outcome_type in ["use", "fav", "expect"]:
            outcome = f"{outcome_type}__{item['key']}"
            biv = two_by_two(d, outcome)
            unadj = fit_model(d, outcome, adjusted=False)
            adj = fit_model(d, outcome, adjusted=True)
            rows.append({
                **item,
                "outcome_type": outcome_type,
                "outcome_variable": outcome,
                **biv,
                **{f"unadjusted_{k}": v for k, v in unadj.items()},
                **{f"adjusted_{k}": v for k, v in adj.items()},
            })
            missing.append({
                "key": item["key"],
                "label": item["label"],
                "family": item["family"],
                "outcome_type": outcome_type,
                "available_n": int(d[outcome].notna().sum()),
                "missing_n": int(d[outcome].isna().sum()),
                "model_complete_case_n": adj["n_model"],
            })

    results = pd.DataFrame(rows)
    cha = results["family"].eq("CHA")
    results["adjusted_q_value"] = np.nan
    results.loc[cha, "adjusted_q_value"] = bh_adjust(results.loc[cha, "adjusted_p_value"])
    return results, pd.DataFrame(missing)


def participant_characteristics(d: pd.DataFrame) -> pd.DataFrame:
    rows = []

    def add_cat(label: str, col: str, levels: dict):
        q = d[["mecfs", col]].dropna()
        tab = pd.crosstab(q["mecfs"], q[col]).reindex(
            index=[0, 1], columns=list(levels), fill_value=0
        )
        _, p, _, expected = chi2_contingency(tab.to_numpy(), correction=False)
        if tab.shape == (2, 2) and (expected < 5).any():
            p = fisher_exact(tab.to_numpy())[1]
        for i, (level, category_label) in enumerate(levels.items()):
            rows.append({
                "characteristic": label if i == 0 else "",
                "category": category_label,
                "comparison_n": int(tab.loc[0, level]),
                "comparison_percent": float(tab.loc[0, level] / tab.loc[0].sum() * 100),
                "mecfs_n": int(tab.loc[1, level]),
                "mecfs_percent": float(tab.loc[1, level] / tab.loc[1].sum() * 100),
                "p_value": float(p) if i == 0 else np.nan,
            })

    add_cat("Age", "age4", {1: "18-34", 2: "35-49", 3: "50-64", 4: "65 and older"})
    add_cat("Sex assigned at birth", "SEX2", {0: "Male", 1: "Female"})
    add_cat(
        "Race/Ethnicity",
        "RACE2",
        {
            1: "Asian, non-Hispanic",
            2: "White/Caucasian, non-Hispanic",
            3: "Black/African American, non-Hispanic",
            4: "Hispanic",
            5: "All additional categories",
        },
    )
    # The final CFS Table 1 reports the two-level education variable.
    edu = d[["mecfs", "EDUCATION_2LEVEL"]].dropna()
    edu_levels = sorted(edu["EDUCATION_2LEVEL"].unique().tolist())
    if len(edu_levels) != 2:
        raise ValueError(f"Expected two EDUCATION_2LEVEL values; observed {edu_levels}")
    # Historical coding is treated as low->high; this avoids assuming whether
    # the stored values are 0/1 or 1/2 while preserving the manuscript labels.
    add_cat(
        "Education",
        "EDUCATION_2LEVEL",
        {edu_levels[0]: "Less than college", edu_levels[1]: "Some college or more"},
    )
    add_cat("Employment", "EMPLOYM", {0: "Not working for pay", 1: "Working part-time", 2: "Working full-time"})
    add_cat("Health insurance", "insurance_corrected", {0: "Uninsured", 1: "Insured"})
    add_cat("Residence size", "COMMSIZE_3Level", {1: "City", 2: "Town", 3: "Village/countryside"})
    add_cat("Poverty category", "POVERTYCAT", {1: "In poverty", 2: "Near poverty", 3: "Above/not in poverty"})
    add_cat("U.S. region", "Region", {1: "East", 2: "Midwest", 3: "South", 4: "West"})
    add_cat("Body mass index", "bmi4", {1: "Underweight", 2: "Normal", 3: "Overweight", 4: "Obese"})
    return pd.DataFrame(rows)


def manuscript_validation(results: pd.DataFrame) -> pd.DataFrame:
    """Check a small set of headline values against the finalized manuscript.

    These checks are intentionally tolerant to displayed rounding. They are an
    audit aid, not a substitute for inspecting the full result tables.
    """
    targets = [
        ("use", "physical", 2.22, 1.60, 3.07, None),
        ("use", "nutritional", 2.25, 1.34, 3.80, 0.019),
        ("use", "combined", 1.89, 1.24, 2.88, 0.021),
        ("use", "systems", 1.99, 1.32, 3.01, 0.010),
        ("use", "overall", 2.46, 0.97, 8.91, None),
        ("fav", "MINDFUL", 0.37, 0.19, 0.70, 0.019),
        ("fav", "NATUROPATH", 5.88, 1.17, 60.44, 0.117),
    ]
    rows = []
    for outcome_type, key, or_t, lo_t, hi_t, q_t in targets:
        r = results[(results.outcome_type == outcome_type) & (results.key == key)]
        if r.empty:
            rows.append({"outcome_type": outcome_type, "key": key, "passed": False, "reason": "missing result"})
            continue
        r = r.iloc[0]
        checks = [
            abs(r.adjusted_or - or_t) <= 0.06,
            abs(r.adjusted_ci_low - lo_t) <= 0.08,
            abs(r.adjusted_ci_high - hi_t) <= max(0.10, hi_t * 0.015),
        ]
        if q_t is not None:
            checks.append(abs(r.adjusted_q_value - q_t) <= 0.003)
        rows.append({
            "outcome_type": outcome_type,
            "key": key,
            "reported_or": or_t,
            "reproduced_or": r.adjusted_or,
            "reported_ci_low": lo_t,
            "reproduced_ci_low": r.adjusted_ci_low,
            "reported_ci_high": hi_t,
            "reproduced_ci_high": r.adjusted_ci_high,
            "reported_q": q_t,
            "reproduced_q": r.adjusted_q_value,
            "passed": bool(all(checks)),
            "reason": "within displayed-rounding tolerance" if all(checks) else "review mapping/model specification",
        })
    return pd.DataFrame(rows)


def variable_map_frame() -> pd.DataFrame:
    rows = []
    for key, v in MODALITIES.items():
        rows.append({
            "key": key,
            "label": v[0],
            "family": v[1],
            "category": v[2],
            "use_variable": v[3],
            "favorability_variable": v[4],
            "expectation_variable": v[5],
        })
    return pd.DataFrame(rows)


def display_probability(x):
    """Retain four decimals near .05 so rounding cannot change interpretation."""
    if pd.isna(x):
        return ''
    if x < .001:
        return '<0.001'
    return f'{x:.4f}' if .045 <= x <= .055 else f'{x:.3f}'


def display_odds(row, prefix):
    if pd.isna(row[f'{prefix}_or']):
        return 'not estimable'
    def two(x):
        return str(Decimal(str(x)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))
    return (f"{two(row[f'{prefix}_or'])} "
            f"({two(row[f'{prefix}_ci_low'])}-{two(row[f'{prefix}_ci_high'])})")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, type=Path, help="De-identified CFS public-use CSV")
    ap.add_argument("--spec", required=True, type=Path, help="Frozen JSON analysis specification")
    ap.add_argument("--output-dir", required=True, type=Path, help="Directory for analysis outputs")
    args = ap.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    spec = json.loads(args.spec.read_text(encoding="utf-8"))

    d, source_meta = load_data(args.data)

    exposure_col = resolve_exposure_column(d, spec)
    d["mecfs"] = d[exposure_col]
    d, covariate_checks = derive_covariates(d)
    d, checks = rebuild_outcomes(d)
    checks.extend(covariate_checks)

    # Hard structural checks.
    checks.extend([
        {
            "check": "analytic_n_3022",
            "passed": len(d) == spec["analytic_subset"]["expected_n"],
            "observed": len(d),
        },
        {
            "check": "public_data_has_no_master_identifiers",
            "passed": all(x not in d.columns for x in ["id", "IPAddress", "ResponseId", "RecipientEmail", "RecordedDate"]),
        },
        {
            "check": "insurance_2702_320",
            "passed": bool((d.insurance_corrected == 1).sum() == 2702 and (d.insurance_corrected == 0).sum() == 320),
            "insured": int((d.insurance_corrected == 1).sum()),
            "uninsured": int((d.insurance_corrected == 0).sum()),
        },
        {
            "check": "28_CHA_7_conventional",
            "passed": len(CHA_KEYS) == 28 and len(CONVENTIONAL_KEYS) == 7,
            "cha": len(CHA_KEYS),
            "conventional": len(CONVENTIONAL_KEYS),
        },
        {
            "check": "exact_exposure_variable",
            "passed": exposure_col == "HXM_ChronicFatigueSyndrome",
            "observed": exposure_col,
        },
        {
            "check": "education_2level_present",
            "passed": "EDUCATION_2LEVEL" in d.columns and d["EDUCATION_2LEVEL"].nunique(dropna=True) == 2,
            "observed_levels": sorted(d["EDUCATION_2LEVEL"].dropna().unique().tolist()) if "EDUCATION_2LEVEL" in d.columns else [],
        },
        {
            "check": "mecfs_counts_167_2855",
            "passed": bool((d.mecfs == 1).sum() == 167 and (d.mecfs == 0).sum() == 2855),
            "cases": int((d.mecfs == 1).sum()),
            "comparison": int((d.mecfs == 0).sum()),
            "resolved_source_variable": exposure_col,
        },
        {
            "check": "derived_covariates_complete",
            "passed": bool(d[["age4", "race4", "bmi4"]].notna().all().all()),
        },
    ])

    results, missing = run_analysis(d)
    participant = participant_characteristics(d)
    validation = manuscript_validation(results)

    checks.extend([
        {
            "check": "model_inventory_123",
            "passed": len(results) == 123,
            "observed": len(results),
        },
        {
            "check": "CHA_model_inventory_102",
            "passed": int(results.family.eq("CHA").sum()) == 102,
            "observed": int(results.family.eq("CHA").sum()),
        },
        {
            "check": "conventional_model_inventory_21",
            "passed": int(results.family.eq("conventional").sum()) == 21,
            "observed": int(results.family.eq("conventional").sum()),
        },
        {
            "check": "adjusted_Firth_models_20",
            "passed": int(results.adjusted_method.eq("Firth penalized logistic").sum()) == int(spec.get("expected_firth_models", 20)),
            "observed": int(results.adjusted_method.eq("Firth penalized logistic").sum()),
        },
        {
            "check": "max_VIF_matches_reconciled_design",
            "passed": float(results.adjusted_max_vif.max()) <= 2.85,
            "observed": float(results.adjusted_max_vif.max()),
            "manuscript_reported": 2.79,
        },
        {
            "check": "mecfs_VIF_matches_reconciled_design",
            "passed": float(results.adjusted_focal_vif.max()) <= 1.35,
            "observed": float(results.adjusted_focal_vif.max()),
            "manuscript_reported_maximum": 1.31,
        },
    ])

    # Full-precision results.
    results.to_csv(args.output_dir / "cfs_results_full_precision.csv", index=False)

    # Human-readable manuscript table export.
    display = results[["family", "outcome_type", "level", "key", "label"]].copy()
    display["comparison_n_N_percent"] = results.apply(
        lambda x: f"{int(x.comparison_events)}/{int(x.comparison_n)} ({x.comparison_percent:.1f}%)", axis=1
    )
    display["mecfs_n_N_percent"] = results.apply(
        lambda x: f"{int(x.case_events)}/{int(x.case_n)} ({x.case_percent:.1f}%)", axis=1
    )
    display["bivariate_p"] = results.bivariate_p.map(display_probability)
    display["unadjusted_OR_95CI"] = results.apply(
        lambda x: display_odds(x, 'unadjusted'), axis=1
    )
    display["adjusted_OR_95CI"] = results.apply(
        lambda x: display_odds(x, 'adjusted'), axis=1
    )
    display["adjusted_p"] = results.adjusted_p_value.map(display_probability)
    display["adjusted_q"] = results.adjusted_q_value.map(display_probability)
    display["model_N"] = results.adjusted_n_model.astype(int)
    display["method"] = results.adjusted_method
    display.to_csv(args.output_dir / "cfs_results_manuscript_ready.csv", index=False)

    missing.to_csv(args.output_dir / "cfs_missingness_by_model.csv", index=False)
    participant.to_csv(args.output_dir / "cfs_participant_characteristics.csv", index=False)
    variable_map_frame().to_csv(args.output_dir / "cfs_variable_map.csv", index=False)
    validation.to_csv(args.output_dir / "cfs_manuscript_validation.csv", index=False)
    pd.DataFrame(checks).to_csv(args.output_dir / "cfs_invariant_checks.csv", index=False)

    metadata = {
        "source": source_meta,
        "resolved_exposure_variable": exposure_col,
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scipy": scipy.__version__,
        },
        "spec": spec,
    }
    (args.output_dir / "cfs_run_metadata.json").write_text(
        json.dumps(metadata, indent=2, default=str), encoding="utf-8"
    )

    summary = {
        "analytic_n": len(d),
        "mecfs_cases": int((d.mecfs == 1).sum()),
        "comparison": int((d.mecfs == 0).sum()),
        "resolved_exposure_variable": exposure_col,
        "models": len(results),
        "cha_models": int(results.family.eq("CHA").sum()),
        "conventional_models": int(results.family.eq("conventional").sum()),
        "firth_adjusted": int(results.adjusted_method.eq("Firth penalized logistic").sum()),
        "headline_validation_passed": bool(validation.passed.all()),
        "all_structural_invariants_passed": all(x.get("passed", False) for x in checks),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
