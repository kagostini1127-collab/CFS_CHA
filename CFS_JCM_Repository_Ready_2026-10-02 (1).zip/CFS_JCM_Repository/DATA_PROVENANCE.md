# Analytic data and provenance

`CFS_JCM_public_data.csv` contains the complete respondent-level input needed for this paper: 3,022 respondents and 117 numeric columns. There are 167 respondents reporting clinician-diagnosed chronic fatigue syndrome and 2,855 comparison respondents. This is an observed survey dataset, not synthetic data.

The input was taken unchanged from `CFS_JCM_Reproducibility_Package_REVISED_2026-10-01.zip`. This release validates the supplied public analytic CSV; it does not repeat extraction from the private parent SPSS file. The public CSV SHA-256 is `1ae9575137f6ac70f2a0dc618886e4ca5a68615bcde23e96a6d052a09326f3c8`.

## Fields retained

There are 12 exposure/demographic/coding fields and 105 intervention fields (use, favorability, expectation for 35 interventions). Both `RACE2` and `RACE_4Level` are retained because the descriptive table and regressions use different race codings. `insurance_corrected` contains the public-or-private coverage indicator derived in the earlier release. The private insurance source fields are not required for model reproduction and are not included.

The whitelist is independently checked in `Reproduce.py` against the entire CSV schema and the manifest. All values are numeric; all exposure/covariate/use values and rating ranges are checked. Survey routing and the five-to-four-level race recode are checked row by row. No observations are dropped or deduplicated by this release.

## Excluded fields

The analytic CSV contains no IP addresses, respondent identifiers, names, email addresses, street addresses, precise location, timestamps, Qualtrics administrative fields, free text, exact age, continuous BMI, unrelated diagnoses, or unrelated scales. The preceding public release documented randomized row order; no source-record linkage or mapping is included here. The original master dataset is excluded from this repository.

## Coding and missing values

Blank CSV cells mean structurally inapplicable ratings: favorability is available for users and expectation for nonusers. Eligible ratings are complete in this release. Blank values must not be treated as zero. Ratings are ordered integers from 1 to 6, with individual ratings 4–6 coded positive. Category/overall composites use the available applicable ratings and the historically implemented mean ≥3.5 threshold.

Use `CFS_JCM_variable_manifest.csv` for per-column roles, source labels, and coding. The manifest preserves source-question wording, including original spelling. The term ME/CFS refers to the survey's reported clinician diagnosis; diagnostic criteria were not independently measured.

## Public sharing scope

Removal of identifiers and unnecessary fields is verified; this does not certify that combinations of demographic and health responses cannot be reidentified. Institutional/consent authorization for unrestricted row-level sharing is not established by the computational audit. This package does not impose a new data or software license on the authors' behalf.
